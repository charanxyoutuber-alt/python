# Case Study 50: Tuple-Based Route Distance Analysis

## 1. Problem Statement
Store geographical/grid coordinates as tuples along a route, calculate distances between successive points, compute total route length, and identify the longest route segment.

## 2. Objectives
* Represent route stops/waypoints as coordinate tuples `(x, y)` inside a list.
* Use tuple unpacking to compute Euclidean distances between consecutive waypoints.
* Calculate total route distance and identify which segment is the longest.

## 3. Assumptions
* Route has at least `2` waypoints (`num_points >= 2`).
* Each waypoint is represented as `(x, y)` with numeric coordinates (`float`).
* Distance between `(x1, y1)` and `(x2, y2)` is Euclidean distance: $\sqrt{(x_2 - x_1)^2 + (y_2 - y_1)^2}$ using exponentiation `** 0.5`.

## 4. Algorithm
1. Start.
2. Read `num_points` (`>= 2`).
3. Read `x` and `y` for each point and store `(x, y)` in a list `waypoints`.
4. Loop `i` from `0` to `len(waypoints) - 2`:
   * Unpack `x1, y1 = waypoints[i]` and `x2, y2 = waypoints[i + 1]`.
   * Compute `dist = ((x2 - x1) ** 2 + (y2 - y1) ** 2) ** 0.5`.
   * Add `dist` to `total_dist` and store segment info.
   * Track the longest segment.
5. Display segment distances, total distance, and the longest segment.
6. Stop.

## 5. Flowchart
```text
[Start]
   |
   v
[Read num_points >= 2 & store (x, y) tuples in list]
   |
   v
[For i = 0 to len(waypoints) - 2]
   |-- Unpack (x1, y1) and (x2, y2)
   |-- Compute Euclidean distance
   |-- Add to total_dist & check if longest segment
   |
   v
[Display segments, total distance & longest segment]
   |
   v
[Stop]
```

## 6. Pseudocode
```text
BEGIN
    REPEAT
        READ num_points
    UNTIL num_points >= 2

    CREATE waypoints = []
    FOR i FROM 1 TO num_points DO
        READ x, y
        APPEND (x, y) TO waypoints
    END FOR

    total_dist = 0.0
    max_dist = -1.0
    longest_seg = 0

    FOR i FROM 0 TO LENGTH(waypoints) - 2 DO
        x1, y1 = waypoints[i]
        x2, y2 = waypoints[i + 1]
        d = ((x2 - x1) ** 2 + (y2 - y1) ** 2) ** 0.5
        total_dist = total_dist + d
        PRINT "Segment", i + 1, ":", d
        IF d > max_dist THEN
            max_dist = d
            longest_seg = i + 1
        END IF
    END FOR

    PRINT "Total Distance:", total_dist
    PRINT "Longest Segment:", longest_seg, "with distance:", max_dist
END
```

## 7. Python Source Code
```python
num_points = int(input("Enter number of route waypoints (>= 2): "))
while num_points < 2:
    print("At least 2 waypoints are required to form a route.")
    num_points = int(input("Enter number of route waypoints (>= 2): "))

waypoints = []
for idx in range(1, num_points + 1):
    x = float(input(f"Enter x coordinate for Point {idx}: "))
    y = float(input(f"Enter y coordinate for Point {idx}: "))
    point = (x, y)
    waypoints.append(point)

total_distance = 0.0
max_distance = -1.0
longest_segment_num = 0
longest_start = (0.0, 0.0)
longest_end = (0.0, 0.0)

print("\n--- Route Segment Distances ---")
for i in range(len(waypoints) - 1):
    x1, y1 = waypoints[i]
    x2, y2 = waypoints[i + 1]
    seg_dist = (((x2 - x1) ** 2) + ((y2 - y1) ** 2)) ** 0.5
    total_distance += seg_dist
    seg_num = i + 1
    print(f"Segment {seg_num} ({x1}, {y1}) -> ({x2}, {y2}) : {seg_dist:.2f} units")

    if seg_dist > max_distance:
        max_distance = seg_dist
        longest_segment_num = seg_num
        longest_start = (x1, y1)
        longest_end = (x2, y2)

print("\n--- Route Summary ---")
print(f"Total Route Distance : {total_distance:.2f} units")
print(
    f"Longest Segment      : Segment {longest_segment_num} "
    f"{longest_start} -> {longest_end} ({max_distance:.2f} units)"
)
```

## 8. Test Cases
* **Normal Case:** Points `(0, 0)`, `(3, 4)`, `(3, 10)` $\rightarrow$ Segment 1 = `5.00`, Segment 2 = `6.00`, Total = `11.00`, Longest = Segment 2 (`6.00`).
* **Zero-Movement Boundary Case:** Points `(2, 2)`, `(2, 2)` $\rightarrow$ Segment distance = `0.00`.
* **Invalid Count Case:** `num_points = 1` $\rightarrow$ Rejected until `>= 2`.

## 9. Output Screenshots
Run `case_study_50_route_distance.py` with sample coordinates and capture the output screenshot.

## 10. Conclusion
The program computes route distances and identifies the longest segment cleanly using coordinate tuples, tuple unpacking, and arithmetic operators.