# Case Study 51: Bus Passenger Occupancy Simulation

## 1. Problem Statement
Process boarding and alighting counts across multiple bus stops, calculate passenger occupancy at each stop, and flag any capacity violations.

## 2. Objectives
* Represent each stop's boarding and alighting counts using tuples `(boarding, alighting)` inside a list.
* Track running passenger occupancy across stops and prevent negative occupancy.
* Detect and flag stops where occupancy exceeds the bus seating/standing capacity.

## 3. Assumptions
* Bus maximum capacity is a positive integer (`capacity >= 1`).
* Initial passenger count at start of route is `0`.
* Boarding and alighting values at each stop are non-negative integers (`>= 0`).
* If `alighting > current_passengers`, only `current_passengers` can alight (and a warning is noted).

## 4. Algorithm
1. Start.
2. Read `capacity` (`>= 1`) and number of stops `num_stops` (`>= 1`).
3. For each stop, read `boarding` and `alighting` (`>= 0`) and append `(boarding, alighting)` to `stops_data`.
4. Initialize `occupancy = 0` and loop through each stop tuple:
   * Unpack `board, alight = stops_data[i]`.
   * Adjust `alight` if greater than `occupancy`, update `occupancy = occupancy - actual_alight + board`.
   * Check if `occupancy > capacity` and flag an overload violation.
5. Display stop-by-stop occupancy and any capacity violations.
6. Stop.

## 5. Flowchart
```text
[Start]
   |
   v
[Read bus capacity & num_stops; collect (board, alight) tuples]
   |
   v
[occupancy = 0; loop through stops]
   |-- Unpack board, alight
   |-- Adjust alight if > occupancy
   |-- occupancy = occupancy - alight + board
   |-- If occupancy > capacity --> Flag overload
   |
   v
[Print stop log & capacity violations]
   |
   v
[Stop]
```

## 6. Pseudocode
```text
BEGIN
    READ capacity (capacity >= 1)
    READ num_stops (num_stops >= 1)
    CREATE stops_data = []

    FOR s FROM 1 TO num_stops DO
        REPEAT
            READ board, alight
        UNTIL board >= 0 AND alight >= 0
        APPEND (board, alight) TO stops_data
    END FOR

    occupancy = 0
    violations = 0
    FOR i FROM 0 TO LENGTH(stops_data) - 1 DO
        board, alight = stops_data[i]
        IF alight > occupancy THEN
            actual_alight = occupancy
            PRINT "Warning at Stop", i + 1, ": alight capped from", alight, "to", actual_alight
        ELSE
            actual_alight = alight
        END IF
        occupancy = occupancy - actual_alight + board
        PRINT "Stop", i + 1, "Occupancy:", occupancy
        IF occupancy > capacity THEN
            PRINT "OVERLOAD at Stop", i + 1, "by", occupancy - capacity, "passengers"
            violations = violations + 1
        END IF
    END FOR

    PRINT "Total Overload Stops:", violations
END
```

## 7. Python Source Code
```python
capacity = int(input("Enter maximum bus capacity: "))
while capacity <= 0:
    print("Bus capacity must be a positive integer.")
    capacity = int(input("Enter maximum bus capacity: "))

num_stops = int(input("Enter number of stops on route: "))
while num_stops <= 0:
    print("Number of stops must be at least 1.")
    num_stops = int(input("Enter number of stops on route: "))

stops_data = []
for s in range(1, num_stops + 1):
    board = int(input(f"\nStop {s} - passengers boarding: "))
    while board < 0:
        print("Boarding count cannot be negative.")
        board = int(input(f"Stop {s} - passengers boarding: "))

    alight = int(input(f"Stop {s} - passengers alighting: "))
    while alight < 0:
        print("Alighting count cannot be negative.")
        alight = int(input(f"Stop {s} - passengers alighting: "))

    stops_data.append((board, alight))

occupancy = 0
overload_stops = 0

print("\n--- Bus Occupancy Simulation ---")
for i in range(num_stops):
    board, alight = stops_data[i]
    stop_num = i + 1

    if alight > occupancy:
        print(
            f"Stop {stop_num} Notice: {alight} tried to alight, "
            f"but only {occupancy} on board. Capping alighting to {occupancy}."
        )
        actual_alight = occupancy
    else:
        actual_alight = alight

    occupancy = occupancy - actual_alight + board

    if occupancy > capacity:
        excess = occupancy - capacity
        overload_stops += 1
        print(
            f"Stop {stop_num}: Boarding={board}, Alighting={actual_alight} | "
            f"Occupancy={occupancy}/{capacity} [OVERLOAD by {excess}]"
        )
    else:
        print(
            f"Stop {stop_num}: Boarding={board}, Alighting={actual_alight} | "
            f"Occupancy={occupancy}/{capacity} [OK]"
        )

print("\n--- Route Occupancy Summary ---")
print(f"Final Occupancy : {occupancy}/{capacity}")
print(f"Overload Stops  : {overload_stops}")
```

## 8. Test Cases
* **Normal / Overload Case:** Capacity `40`, stops `[(25, 0), (20, 5), (0, 10)]` $\rightarrow$ Stop 1: `25/40` (`OK`), Stop 2: `40/40` (`OK`), Stop 3: `30/40` (`OK`). If Stop 2 had `(25, 5)` $\rightarrow$ `45/40` (`OVERLOAD by 5`).
* **Excess Alighting Case:** Occupancy `10`, stop has `(5, 15)` $\rightarrow$ Alighting capped to `10`, final occupancy `5`.
* **Invalid Input Case:** Negative boarding/alighting $\rightarrow$ Rejected and re-prompted.

## 9. Output Screenshots
Run `case_study_51_bus_occupancy.py` with sample stop counts and capture the output screenshot.

## 10. Conclusion
The program simulates passenger flow across stops and flags capacity overloads using tuples, tuple unpacking, loops, and conditional checks.