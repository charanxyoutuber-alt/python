# Case Study 13: ATM Transaction Sequence Simulation

## 1. Problem Statement
Process a sequence of deposits and withdrawals, maintain a simulated balance, enforce withdrawal limits, reject invalid transactions, and produce a transaction summary.

## 2. Objectives
* Store and process a sequence of ATM transactions using lists.
* Validate deposits and withdrawals against non-positive amounts, available balance, and per-transaction/daily withdrawal limits.
* Output accepted transactions, rejected transactions with reasons, and final balance summary.

## 3. Assumptions
* Initial account balance is provided by the user (`>= 0`).
* Per-withdrawal limit is `₹20,000.00`, and total daily withdrawal limit is `₹40,000.00`.
* Transaction format entered by user: `D <amount>` for deposit or `W <amount>` for withdrawal (e.g., `D 5000`, `W 2500`).
* Amounts must be strictly greater than `0`.

## 4. Algorithm
1. Start.
2. Read initial `balance` (validate `balance >= 0`).
3. Read number of transactions `m` (`m >= 0`) and collect each transaction string into a list `transactions`.
4. Initialize `total_deposited = 0.0`, `total_withdrawn = 0.0`, `accepted_count = 0`, `rejected_count = 0`, and `summary_log = []`.
5. Loop through each item in `transactions`:
   * Parse type (`D` or `W`) and numeric amount.
   * Validate format and `amount > 0`.
   * For `D`: add to `balance` and `total_deposited`, record as accepted.
   * For `W`: check `amount <= 20000`, `total_withdrawn + amount <= 40000`, and `amount <= balance`; if valid, deduct from `balance` and add to `total_withdrawn`, else reject with reason.
6. Print transaction log and final summary.
7. Stop.

## 5. Flowchart
```text
[Start]
   |
   v
[Read initial balance & transaction list]
   |
   v
[For each transaction in list]
   |-- Invalid type/amount <= 0 --> Reject
   |-- Deposit (D)              --> balance += amt; log Accepted
   |-- Withdrawal (W)           --> Check limits & balance
        |-- Valid               --> balance -= amt; log Accepted
        |-- Exceeds limit/bal   --> Reject with reason
   |
   v
[Print log & final balance summary]
   |
   v
[Stop]
```

## 6. Pseudocode
```text
BEGIN
    READ balance
    READ m
    CREATE empty list transactions
    FOR i FROM 1 TO m DO
        READ txn_str
        APPEND txn_str TO transactions
    END FOR

    per_txn_limit = 20000.0
    daily_limit = 40000.0
    withdrawn_today = 0.0
    deposited_today = 0.0
    accepted = 0
    rejected = 0

    FOR EACH txn IN transactions DO
        SPLIT txn into parts
        IF parts count != 2 THEN
            PRINT "Rejected (bad format):", txn
            rejected = rejected + 1
            CONTINUE
        END IF
        t_type = UPPER(parts[0])
        amt = FLOAT(parts[1])
        IF amt <= 0 THEN
            PRINT "Rejected (non-positive amount):", txn
            rejected = rejected + 1
        ELSE IF t_type == "D" THEN
            balance = balance + amt
            deposited_today = deposited_today + amt
            accepted = accepted + 1
            PRINT "Accepted Deposit:", amt, "| Balance:", balance
        ELSE IF t_type == "W" THEN
            IF amt > per_txn_limit THEN
                PRINT "Rejected (exceeds Rs.20,000 limit):", amt
                rejected = rejected + 1
            ELSE IF withdrawn_today + amt > daily_limit THEN
                PRINT "Rejected (exceeds Rs.40,000 daily limit):", amt
                rejected = rejected + 1
            ELSE IF amt > balance THEN
                PRINT "Rejected (insufficient balance):", amt
                rejected = rejected + 1
            ELSE
                balance = balance - amt
                withdrawn_today = withdrawn_today + amt
                accepted = accepted + 1
                PRINT "Accepted Withdrawal:", amt, "| Balance:", balance
            END IF
        ELSE
            PRINT "Rejected (unknown type):", txn
            rejected = rejected + 1
        END IF
    END FOR

    PRINT "Final Balance:", balance, "Accepted:", accepted, "Rejected:", rejected
END
```

## 7. Python Source Code
```python
balance = float(input("Enter initial account balance (Rs.): "))
while balance < 0:
    print("Initial balance cannot be negative.")
    balance = float(input("Enter initial account balance (Rs.): "))

n = int(input("Enter number of transactions to process: "))
while n < 0:
    print("Number of transactions cannot be negative.")
    n = int(input("Enter number of transactions to process: "))

transactions = []
for i in range(1, n + 1):
    entry = input(f"Enter transaction {i} (e.g., D 5000 or W 2000): ").strip()
    transactions.append(entry)

PER_TXN_LIMIT = 20000.0
DAILY_WITHDRAWAL_LIMIT = 40000.0

total_deposited = 0.0
total_withdrawn = 0.0
accepted_count = 0
rejected_count = 0

print("\n--- Transaction Processing Log ---")
for txn in transactions:
    parts = txn.split()
    if len(parts) != 2:
        print(f"[REJECTED] '{txn}' -> Invalid format.")
        rejected_count += 1
        continue

    txn_type = parts[0].upper()
    # Validate numeric amount safely using string checks
    amt_str = parts[1]
    dot_count = amt_str.count(".")
    cleaned = amt_str.replace(".", "", 1)
    if dot_count > 1 or not cleaned.isdigit():
        print(f"[REJECTED] '{txn}' -> Invalid amount.")
        rejected_count += 1
        continue

    amount = float(amt_str)
    if amount <= 0:
        print(f"[REJECTED] '{txn}' -> Amount must be greater than zero.")
        rejected_count += 1
    elif txn_type == "D":
        balance += amount
        total_deposited += amount
        accepted_count += 1
        print(f"[ACCEPTED] Deposit Rs. {amount:.2f} | New Balance: Rs. {balance:.2f}")
    elif txn_type == "W":
        if amount > PER_TXN_LIMIT:
            print(f"[REJECTED] Withdrawal Rs. {amount:.2f} -> Exceeds per-transaction limit (Rs. 20000).")
            rejected_count += 1
        elif total_withdrawn + amount > DAILY_WITHDRAWAL_LIMIT:
            print(f"[REJECTED] Withdrawal Rs. {amount:.2f} -> Exceeds daily limit (Rs. 40000).")
            rejected_count += 1
        elif amount > balance:
            print(f"[REJECTED] Withdrawal Rs. {amount:.2f} -> Insufficient balance (Rs. {balance:.2f}).")
            rejected_count += 1
        else:
            balance -= amount
            total_withdrawn += amount
            accepted_count += 1
            print(f"[ACCEPTED] Withdrawal Rs. {amount:.2f} | New Balance: Rs. {balance:.2f}")
    else:
        print(f"[REJECTED] '{txn}' -> Unknown transaction code '{txn_type}'.")
        rejected_count += 1

print("\n--- ATM Session Summary ---")
print(f"Total Deposited  : Rs. {total_deposited:.2f}")
print(f"Total Withdrawn  : Rs. {total_withdrawn:.2f}")
print(f"Accepted Txns    : {accepted_count}")
print(f"Rejected Txns    : {rejected_count}")
print(f"Final Balance    : Rs. {balance:.2f}")
```

## 8. Test Cases
* **Normal Case:** Initial `10000`, transactions `["D 5000", "W 3000"]` $\rightarrow$ Final balance `Rs. 12000.00`, `2` accepted.
* **Limit / Insufficient Balance Case:** Initial `5000`, transactions `["W 25000", "W 6000"]` $\rightarrow$ First rejected for exceeding `20000`, second rejected for insufficient balance.
* **Invalid Input Case:** Transaction `"W -100"` or `"X 500"` $\rightarrow$ Rejected cleanly without crashing.

## 9. Output Screenshots
Run `case_study_13_atm_simulation.py` in your terminal/IDE with sample deposits and withdrawals and capture the screenshot.

## 10. Conclusion
The ATM simulation processes sequential transactions, enforces limits and balance rules, and produces a clear summary using lists, string operations, and conditional logic.