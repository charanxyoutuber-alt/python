# Case Study 31: String-Based Examination Answer Evaluation

## 1. Problem Statement
Compare student answer strings against an answer key, calculate correct, incorrect, and unanswered responses, apply negative marking, and produce student-wise results.

## 2. Objectives
* Validate that student response strings match the length of the answer key.
* Count correct, incorrect, and unanswered (`'-'`) questions using string indexing/iteration.
* Apply positive and negative marking rules and display each student's score and result status.

## 3. Assumptions
* Answer key is a non-empty uppercase string of choices (e.g., `ABCDABCDAB`).
* In a student's answer string:
  * Matching character with answer key = Correct (`+4` marks)
  * `'-'` (or `' '`) = Unanswered (`0` marks)
  * Any other character not matching the key = Incorrect (`-1` mark)
* Pass threshold is `40%` of maximum marks (`4 * len(key)`).

## 4. Algorithm
1. Start.
2. Read `answer_key` (non-empty string) and convert to uppercase.
3. Read number of students `num_students` (`>= 1`).
4. For each student:
   * Read student name and answer string.
   * Validate length equals `len(answer_key)`; re-prompt if mismatched.
   * Iterate character-by-character across `0` to `len(answer_key) - 1` to count `correct`, `incorrect`, and `unanswered`.
   * Calculate `score = (correct * 4) - (incorrect * 1)` and percentage.
   * Determine `PASS` or `FAIL` and store student summary in a list.
5. Display all student results.
6. Stop.

## 5. Flowchart
```text
[Start]
   |
   v
[Read answer_key & num_students]
   |
   v
[For each student]
   |-- Read name & answers (validate length)
   |-- Loop index i from 0 to len(key)-1:
        |-- ans[i] == key[i] --> correct += 1
        |-- ans[i] == '-'    --> unanswered += 1
        |-- else             --> incorrect += 1
   |-- score = correct * 4 - incorrect * 1
   |-- Store result in list
   |
   v
[Print student-wise results]
   |
   v
[Stop]
```

## 6. Pseudocode
```text
BEGIN
    READ answer_key (non-empty)
    key = UPPER(answer_key)
    READ num_students (num_students >= 1)
    CREATE empty list results

    FOR s FROM 1 TO num_students DO
        READ name
        REPEAT
            READ ans
            ans = UPPER(ans)
        UNTIL LENGTH(ans) == LENGTH(key)

        correct = 0
        incorrect = 0
        unanswered = 0

        FOR i FROM 0 TO LENGTH(key) - 1 DO
            IF ans[i] == key[i] THEN
                correct = correct + 1
            ELSE IF ans[i] == '-' THEN
                unanswered = unanswered + 1
            ELSE
                incorrect = incorrect + 1
            END IF
        END FOR

        score = (correct * 4) - incorrect
        max_marks = LENGTH(key) * 4
        pct = (score / max_marks) * 100
        status = "PASS" IF pct >= 40 ELSE "FAIL"
        APPEND (name, correct, incorrect, unanswered, score, max_marks, pct, status) TO results
    END FOR

    FOR EACH item IN results DO
        PRINT item
    END FOR
END
```

## 7. Python Source Code
```python
answer_key = input("Enter answer key (e.g., ABCDAB): ").strip().upper()
while len(answer_key) == 0:
    print("Answer key cannot be empty.")
    answer_key = input("Enter answer key: ").strip().upper()

num_students = int(input("Enter number of students: "))
while num_students <= 0:
    print("Number of students must be at least 1.")
    num_students = int(input("Enter number of students: "))

max_marks = len(answer_key) * 4
results = []

for s in range(1, num_students + 1):
    name = input(f"\nEnter Student {s} name: ").strip()
    ans = input(f"Enter answer string ({len(answer_key)} chars, '-' for blank): ").strip().upper()
    while len(ans) != len(answer_key):
        print(f"Answer length must be {len(answer_key)}. Try again.")
        ans = input(f"Enter answer string ({len(answer_key)} chars): ").strip().upper()

    correct = 0
    incorrect = 0
    unanswered = 0

    for i in range(len(answer_key)):
        if ans[i] == answer_key[i]:
            correct += 1
        elif ans[i] == "-":
            unanswered += 1
        else:
            incorrect += 1

    score = (correct * 4) - (incorrect * 1)
    percentage = (score / max_marks) * 100.0
    status = "PASS" if percentage >= 40.0 else "FAIL"

    results.append((name, correct, incorrect, unanswered, score, max_marks, round(percentage, 2), status))

print("\n--- Examination Evaluation Results ---")
for name, corr, incorr, unans, sc, mx, pct, st in results:
    print(
        f"{name} | Correct: {corr} | Incorrect: {incorr} | Unanswered: {unans} | "
        f"Score: {sc}/{mx} ({pct:.2f}%) | {st}"
    )
```

## 8. Test Cases
* **Normal Case:** Key `"ABCD"`, Student `"Asha"` answers `"AB-D"` $\rightarrow$ `3` correct (`+12`), `0` incorrect (`0`), `1` unanswered (`0`), Score `12/16` (`75.0%`), `PASS`.
* **Negative Marking Case:** Key `"ABCD"`, Student `"Ravi"` answers `"BBBB"` $\rightarrow$ `1` correct (`+4`), `3` incorrect (`-3`), `0` unanswered, Score `1/16` (`6.25%`), `FAIL`.
* **Length Mismatch Case:** Key `"ABCD"`, answer `"AB"` $\rightarrow$ Rejected and re-prompted until length `4`.

## 9. Output Screenshots
Run `case_study_31_answer_evaluation.py` with sample answer key and student responses and capture the output screenshot.

## 10. Conclusion
The program evaluates student answer strings against a key, applies positive and negative marking, and displays structured results using string indexing, loops, tuples, and tuple unpacking.