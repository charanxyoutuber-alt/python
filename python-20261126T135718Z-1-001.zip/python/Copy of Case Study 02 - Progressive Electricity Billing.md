# Case Study 2: Progressive Electricity Billing

## 1. Problem Statement
Calculate household electricity bills across multiple months using progressive consumption slabs, fixed charges, a surcharge, and a low-usage rebate, then compare monthly bills and flag unusual month-to-month consumption increases.

## 2. Objectives
* Compute monthly electricity bills accurately using slab rates, fixed charges, rebates, and surcharges.
* Store monthly unit readings and bill amounts using lists.
* Compare consecutive months to detect unusual consumption jumps (greater than $30\%$ over the previous month).

## 3. Assumptions
* Units consumed in each month are non-negative integers (`0` or greater).
* Slab structure per month:
  * First `100` units: `₹3.00` per unit
  * Next `100` units (`101–200`): `₹4.50` per unit
  * Above `200` units: `₹6.00` per unit
* Fixed monthly meter charge: `₹50.00`.
* Rebate: `5%` off slab + fixed charges if consumption is `<= 100` units.
* Surcharge: `10%` on slab + fixed charges if consumption is `> 300` units.
* An unusual increase occurs when `current_units > previous_units * 1.30` (for `previous_units > 0`).

## 4. Algorithm
1. Start.
2. Read the number of months `n` (validate `n >= 1`).
3. Initialize an empty list `monthly_units`.
4. Loop `n` times to read units for each month; reject negative values and append valid values to `monthly_units`.
5. Initialize an empty list `monthly_bills`.
6. For each `units` in `monthly_units`, compute slab charges, add fixed charge (`50.0`), apply `5%` rebate if `units <= 100` or `10%` surcharge if `units > 300`, and append the rounded bill to `monthly_bills`.
7. Display each month's consumption and bill.
8. Compare adjacent months (`1` to `n - 1`) and report any increase exceeding `30%`.
9. Stop.

## 5. Flowchart
```text
[Start]
   |
   v
[Read n months & validate units >= 0 into list]
   |
   v
[For each month's units in list]
   |-- units <= 100  --> slab = units * 3.0
   |-- units <= 200  --> slab = 100*3.0 + (units-100)*4.5
   |-- units > 200   --> slab = 100*3.0 + 100*4.5 + (units-200)*6.0
   |
   v
[subtotal = slab + 50.0]
   |-- units <= 100  --> bill = subtotal * 0.95
   |-- units > 300   --> bill = subtotal * 1.10
   |-- otherwise     --> bill = subtotal
   |
   v
[Store bill & print monthly summary]
   |
   v
[Compare consecutive months for >30% unit jump]
   |
   v
[Stop]
```

## 6. Pseudocode
```text
BEGIN
    READ n
    CREATE empty list monthly_units
    FOR i FROM 0 TO n - 1 DO
        REPEAT
            READ u
            IF u < 0 THEN PRINT "Invalid units"
        UNTIL u >= 0
        APPEND u TO monthly_units
    END FOR

    CREATE empty list monthly_bills
    FOR EACH u IN monthly_units DO
        IF u <= 100 THEN
            slab = u * 3.0
        ELSE IF u <= 200 THEN
            slab = (100 * 3.0) + ((u - 100) * 4.5)
        ELSE
            slab = (100 * 3.0) + (100 * 4.5) + ((u - 200) * 6.0)
        END IF

        total = slab + 50.0
        IF u <= 100 THEN
            total = total * 0.95
        ELSE IF u > 300 THEN
            total = total * 1.10
        END IF

        APPEND total TO monthly_bills
    END FOR

    FOR i FROM 0 TO n - 1 DO
        PRINT month, monthly_units[i], monthly_bills[i]
    END FOR

    FOR i FROM 1 TO n - 1 DO
        IF monthly_units[i - 1] > 0 AND monthly_units[i] > monthly_units[i - 1] * 1.3 THEN
            PRINT "Unusual increase from Month", i, "to Month", i + 1
        END IF
    END FOR
END
```

## 7. Python Source Code
```python
n = int(input("Enter number of months to analyze: "))
while n <= 0:
    print("Please enter a positive number of months.")
    n = int(input("Enter number of months to analyze: "))

monthly_units = []
for month in range(1, n + 1):
    units = int(input(f"Enter units consumed for Month {month}: "))
    while units < 0:
        print("Units cannot be negative. Try again.")
        units = int(input(f"Enter units consumed for Month {month}: "))
    monthly_units.append(units)

monthly_bills = []
fixed_charge = 50.0

for units in monthly_units:
    if units <= 100:
        slab_amount = units * 3.0
    elif units <= 200:
        slab_amount = (100 * 3.0) + ((units - 100) * 4.5)
    else:
        slab_amount = (100 * 3.0) + (100 * 4.5) + ((units - 200) * 6.0)

    bill = slab_amount + fixed_charge

    if units <= 100:
        bill = bill * 0.95
    elif units > 300:
        bill = bill * 1.10

    monthly_bills.append(round(bill, 2))

print("\n--- Monthly Electricity Bill Summary ---")
for i in range(n):
    print(f"Month {i + 1}: {monthly_units[i]} units | Bill: Rs. {monthly_bills[i]:.2f}")

print("\n--- Consumption Comparison & Alerts ---")
found_alert = False
for i in range(1, n):
    prev_u = monthly_units[i - 1]
    curr_u = monthly_units[i]
    diff = curr_u - prev_u
    if prev_u > 0 and curr_u > prev_u * 1.30:
        pct_increase = (diff / prev_u) * 100
        print(
            f"ALERT: Unusual increase from Month {i} ({prev_u} units) "
            f"to Month {i + 1} ({curr_u} units) [+{pct_increase:.1f}%]"
        )
        found_alert = True
    else:
        print(f"Month {i} -> Month {i + 1}: Change of {diff:+d} units (Normal)")

if not found_alert:
    print("No unusual consumption spikes detected.")
```

## 8. Test Cases
* **Normal Case:** `n = 2`, `units = [150, 160]` $\rightarrow$ Month 1 bill `Rs. 575.00`, Month 2 bill `Rs. 620.00`, normal change (`+10` units).
* **Boundary / Rebate Case:** `n = 1`, `units = [100]` $\rightarrow$ Slab `300.0` + Fixed `50.0` = `350.0`, `5%` rebate applied $\rightarrow$ `Rs. 332.50`.
* **Spike & Invalid Input Case:** `units = [-5, 120, 200]` $\rightarrow$ Rejects `-5`, `120` to `200` is `+66.7%` $\rightarrow$ Triggers `ALERT`.

## 9. Output Screenshots
Execute `case_study_02_electricity_billing.py` in your terminal or IDE with sample test inputs and attach the screenshot showing both input prompts and output results.

## 10. Conclusion
The program models progressive electricity slabs, rebates, surcharges, and month-to-month anomaly detection using loops, conditionals, and lists within the prescribed syllabus.