# Case Study 35: Text Compression Using Character Runs

## 1. Problem Statement
Encode a string by grouping consecutive repeated characters (run-length encoding) and compare original and encoded lengths, including cases where encoding is not beneficial.

## 2. Objectives
* Group consecutive identical characters in a string using a loop and counter.
* Construct a compressed string representation (e.g., `a4b2c1`).
* Compare original length vs. compressed length and report whether compression saves space.

## 3. Assumptions
* Input text is a non-empty string.
* Case-sensitive run grouping is used (`'A'` and `'a'` are distinct characters).
* Each run is formatted as `<char><count>` (e.g., `'aaa'` becomes `'a3'`).
* Compression is considered beneficial only when `len(encoded) < len(original)`.

## 4. Algorithm
1. Start.
2. Read a non-empty string `text`.
3. Initialize `encoded = ""` and `count = 1`.
4. Loop `i` from `1` to `len(text) - 1`:
   * If `text[i] == text[i - 1]`, increment `count`.
   * Else, append `text[i - 1] + str(count)` to `encoded` and reset `count = 1`.
5. After the loop, append `text[len(text) - 1] + str(count)` to `encoded`.
6. Compare `len(text)` and `len(encoded)` and display whether compression is beneficial.
7. Stop.

## 5. Flowchart
```text
[Start]
   |
   v
[Read non-empty string text]
   |
   v
[encoded = "", count = 1]
   |
   v
[For i = 1 to len(text)-1]
   |-- text[i] == text[i-1] --> count += 1
   |-- else                 --> encoded += text[i-1] + str(count); count = 1
   |
   v
[Append last run: text[-1] + str(count)]
   |
   v
[Compare len(encoded) < len(text) & print result]
   |
   v
[Stop]
```

## 6. Pseudocode
```text
BEGIN
    REPEAT
        READ text
    UNTIL LENGTH(text) > 0

    encoded = ""
    count = 1

    FOR i FROM 1 TO LENGTH(text) - 1 DO
        IF text[i] == text[i - 1] THEN
            count = count + 1
        ELSE
            encoded = encoded + text[i - 1] + TO_STRING(count)
            count = 1
        END IF
    END FOR

    encoded = encoded + text[LENGTH(text) - 1] + TO_STRING(count)

    PRINT "Original:", text, "Length:", LENGTH(text)
    PRINT "Encoded :", encoded, "Length:", LENGTH(encoded)

    IF LENGTH(encoded) < LENGTH(text) THEN
        PRINT "Compression is beneficial. Saved chars:", LENGTH(text) - LENGTH(encoded)
    ELSE
        PRINT "Compression is NOT beneficial."
    END IF
END
```

## 7. Python Source Code
```python
text = input("Enter text to compress: ")
while len(text) == 0:
    print("Input cannot be empty. Please enter some text.")
    text = input("Enter text to compress: ")

encoded = ""
count = 1

for i in range(1, len(text)):
    if text[i] == text[i - 1]:
        count += 1
    else:
        encoded = encoded + text[i - 1] + str(count)
        count = 1

# Append final run
encoded = encoded + text[len(text) - 1] + str(count)

orig_len = len(text)
enc_len = len(encoded)

print("\n--- Run-Length Compression Report ---")
print(f"Original String : {text} (Length: {orig_len})")
print(f"Encoded String  : {encoded} (Length: {enc_len})")

if enc_len < orig_len:
    saved = orig_len - enc_len
    pct_saved = (saved / orig_len) * 100.0
    print(f"Result          : Beneficial (Saved {saved} characters / {pct_saved:.1f}%)")
else:
    print("Result          : Not beneficial (Encoded string is not shorter than original).")
```

## 8. Test Cases
* **Beneficial Case:** `"aaabbbbcc"` (length `9`) $\rightarrow$ `"a3b4c2"` (length `6`), saves `3` characters (`33.3%`).
* **Non-Beneficial Case:** `"abcd"` (length `4`) $\rightarrow$ `"a1b1c1d1"` (length `8`), not beneficial.
* **Single Character Case:** `"z"` (length `1`) $\rightarrow$ `"z1"` (length `2`), not beneficial.

## 9. Output Screenshots
Run `case_study_35_character_runs.py` with both repetitive and non-repetitive strings and capture the output screenshot.

## 10. Conclusion
The program compresses consecutive character runs and evaluates length savings using string concatenation, loops, and conditional checks.