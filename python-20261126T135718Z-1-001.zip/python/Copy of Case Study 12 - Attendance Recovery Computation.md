# Case Study 12: Attendance Recovery Computation

## 1. Problem Statement
Calculate a student's current attendance percentage and determine the minimum number of consecutive classes required to reach a target eligibility threshold under different future attendance scenarios.

## 2. Objectives
* Compute current attendance percentage from attended and conducted classes.
* Use `while` loops and arithmetic operators to find required consecutive classes to reach a target threshold (such as `75%` or `80%`).
* Evaluate multiple future attendance scenarios (e.g., attending every upcoming class vs. attending `80%` of future classes).

## 3. Assumptions
* `conducted >= 1`, `0 <= attended <= conducted`.
* Target eligibility threshold `target_pct` is between `1` and `100` (default test scenarios use `75%` and `80%`).
* In Scenario A (100% recovery): each additional class adds `1` to `attended` and `1` to `conducted`.
* In Scenario B (partial future attendance `p%`): every `100` future classes adds `p` attended classes; simulated step-by-step per class using an accumulator so fractional classes are avoided.
* A safety cap (e.g., `1000` classes) prevents infinite loops if a partial scenario cannot reach the target.

## 4. Algorithm
1. Start.
2. Read `attended` and `conducted` classes; validate `conducted > 0` and `0 <= attended <= conducted`.
3. Calculate `current_pct = (attended / conducted) * 100` and display it.
4. Read `target_pct` (e.g., `75.0`).
5. Using a `while` loop, increment `extra_classes` while `((attended + extra_classes) / (conducted + extra_classes)) * 100 < target_pct`.
6. Display `extra_classes` needed for 100% consecutive attendance.
7. Simulate an `80%` future attendance scenario using a `while` loop until reaching `target_pct` or hitting the cap.
8. Stop.

## 5. Flowchart
```text
[Start]
   |
   v
[Read attended, conducted & validate]
   |
   v
[Compute current_pct = (attended / conducted) * 100]
   |
   v
[Read target_pct]
   |
   v
[While ((att + x) / (cond + x)) * 100 < target_pct]
   |-- x = x + 1
   |
   v
[Display required consecutive classes x]
   |
   v
[Simulate 80% future attendance scenario via while loop]
   |
   v
[Display scenario result & Stop]
```

## 6. Pseudocode
```text
BEGIN
    REPEAT
        READ attended, conducted
    UNTIL conducted > 0 AND attended >= 0 AND attended <= conducted

    current_pct = (attended / conducted) * 100
    PRINT "Current Attendance:", current_pct

    READ target_pct
    x = 0
    WHILE ((attended + x) / (conducted + x)) * 100 < target_pct DO
        x = x + 1
    END WHILE
    PRINT "Consecutive classes needed (100%):", x

    sim_att = attended
    sim_cond = conducted
    sim_classes = 0
    credit_pool = 0
    WHILE (sim_att / sim_cond) * 100 < target_pct AND sim_classes < 1000 DO
        sim_classes = sim_classes + 1
        sim_cond = sim_cond + 1
        credit_pool = credit_pool + 80
        IF credit_pool >= 100 THEN
            sim_att = sim_att + 1
            credit_pool = credit_pool - 100
        END IF
    END WHILE
    PRINT "Classes needed at 80% future attendance:", sim_classes
END
```

## 7. Python Source Code
```python
attended = int(input("Enter classes attended: "))
conducted = int(input("Enter total classes conducted: "))

while conducted <= 0 or attended < 0 or attended > conducted:
    print("Invalid input. Ensure conducted > 0 and 0 <= attended <= conducted.")
    attended = int(input("Enter classes attended: "))
    conducted = int(input("Enter total classes conducted: "))

current_pct = (attended / conducted) * 100.0
print(f"\nCurrent Attendance: {current_pct:.2f}% ({attended}/{conducted})")

target_pct = float(input("Enter target eligibility percentage (e.g., 75): "))
while target_pct <= 0 or target_pct > 100:
    print("Target percentage must be between 0 and 100.")
    target_pct = float(input("Enter target eligibility percentage: "))

# Scenario 1: 100% consecutive attendance
needed_100 = 0
while ((attended + needed_100) / (conducted + needed_100)) * 100.0 < target_pct:
    needed_100 += 1

print(f"Scenario 1 (100% attendance): {needed_100} consecutive classes required.")

# Scenario 2: 80% future attendance rate
sim_att = attended
sim_cond = conducted
needed_80 = 0
credit = 0
max_limit = 1000

while (sim_att / sim_cond) * 100.0 < target_pct and needed_80 < max_limit:
    needed_80 += 1
    sim_cond += 1
    credit += 80
    if credit >= 100:
        sim_att += 1
        credit -= 100

if (sim_att / sim_cond) * 100.0 >= target_pct:
    print(f"Scenario 2 (80% future attendance): {needed_80} classes required.")
else:
    print(f"Scenario 2 (80% future attendance): Target not reachable within {max_limit} classes.")
```

## 8. Test Cases
* **Normal Case:** `attended = 30`, `conducted = 50` (`60.0%`), `target = 75` $\rightarrow$ `30` consecutive classes needed at `100%` (`60/80 = 75.0%`).
* **Already Eligible Boundary Case:** `attended = 38`, `conducted = 50` (`76.0%`), `target = 75` $\rightarrow$ `0` classes needed.
* **Invalid Input Case:** `attended = 55`, `conducted = 50` $\rightarrow$ Rejected and re-prompted.

## 9. Output Screenshots
Run `case_study_12_attendance_recovery.py` with sample attendance numbers and capture the terminal output screenshot.

## 10. Conclusion
The program computes attendance percentages and evaluates recovery requirements across multiple future scenarios using `while` loops, arithmetic operators, and conditionals.