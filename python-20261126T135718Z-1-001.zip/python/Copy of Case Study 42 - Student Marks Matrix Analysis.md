# Case Study 42: Student Marks Matrix Analysis

## 1. Problem Statement
Analyze a matrix of student marks across subjects using nested lists, calculate row-wise and column-wise statistics, identify top performers, and detect subjects with low average performance.

## 2. Objectives
* Represent student marks across multiple subjects as a nested list (`students x subjects`).
* Compute student totals/averages (row-wise) and subject averages (column-wise).
* Identify the highest-scoring student and flag subjects whose average falls below a weak-subject threshold (e.g., `< 50.0`).

## 3. Assumptions
* There are `num_students >= 1` and `num_subjects >= 1`.
* Each mark is a numeric value between `0` and `100`.
* Low-performing subject threshold is `< 50.0` average marks.

## 4. Algorithm
1. Start.
2. Read `num_students` and `num_subjects` (validate `>= 1`).
3. Read student names into `names` and marks into a nested list `marks_matrix`.
4. Compute each student's total and average across subjects; find the student with the highest total/average.
5. Compute each subject's average across all students; identify subjects with average `< 50.0`.
6. Display the matrix, student-wise statistics, top performer, and weak subjects.
7. Stop.

## 5. Flowchart
```text
[Start]
   |
   v
[Read num_students, num_subjects & fill nested marks list]
   |
   v
[Row-wise loop: compute student totals, averages & top student]
   |
   v
[Column-wise loop: compute subject averages & flag < 50.0]
   |
   v
[Display matrix, top student & weak subjects]
   |
   v
[Stop]
```

## 6. Pseudocode
```text
BEGIN
    READ num_students, num_subjects
    CREATE names = [], matrix = []

    FOR i FROM 0 TO num_students - 1 DO
        READ name
        APPEND name TO names
        CREATE row = []
        FOR j FROM 0 TO num_subjects - 1 DO
            REPEAT
                READ m
            UNTIL m >= 0 AND m <= 100
            APPEND m TO row
        END FOR
        APPEND row TO matrix
    END FOR

    top_idx = 0
    top_total = -1
    FOR i FROM 0 TO num_students - 1 DO
        total = 0
        FOR j FROM 0 TO num_subjects - 1 DO
            total = total + matrix[i][j]
        END FOR
        avg = total / num_subjects
        PRINT names[i], total, avg
        IF total > top_total THEN
            top_total = total
            top_idx = i
        END IF
    END FOR
    PRINT "Top Performer:", names[top_idx]

    FOR j FROM 0 TO num_subjects - 1 DO
        col_sum = 0
        FOR i FROM 0 TO num_students - 1 DO
            col_sum = col_sum + matrix[i][j]
        END FOR
        col_avg = col_sum / num_students
        PRINT "Subject", j + 1, "Avg:", col_avg
        IF col_avg < 50 THEN
            PRINT "Weak Subject Alert: Subject", j + 1
        END IF
    END FOR
END
```

## 7. Python Source Code
```python
num_students = int(input("Enter number of students: "))
while num_students <= 0:
    print("Number of students must be at least 1.")
    num_students = int(input("Enter number of students: "))

num_subjects = int(input("Enter number of subjects: "))
while num_subjects <= 0:
    print("Number of subjects must be at least 1.")
    num_subjects = int(input("Enter number of subjects: "))

names = []
marks_matrix = []

for i in range(num_students):
    name = input(f"\nEnter name for Student {i + 1}: ").strip()
    names.append(name)
    row = []
    for j in range(num_subjects):
        mark = float(input(f"  Enter mark for Subject {j + 1} (0-100): "))
        while mark < 0 or mark > 100:
            print("  Mark must be between 0 and 100.")
            mark = float(input(f"  Enter mark for Subject {j + 1} (0-100): "))
        row.append(mark)
    marks_matrix.append(row)

print("\n--- Student-Wise Performance ---")
top_index = 0
highest_total = -1.0

for i in range(num_students):
    total = 0.0
    for j in range(num_subjects):
        total += marks_matrix[i][j]
    avg = total / num_subjects
    print(f"{names[i]} -> Total: {total:.1f} | Average: {avg:.2f}")
    if total > highest_total:
        highest_total = total
        top_index = i

print(f"\nTop Performer: {names[top_index]} (Total: {highest_total:.1f})")

print("\n--- Subject-Wise Average & Weak Subject Check (< 50.0) ---")
weak_subjects = []
for j in range(num_subjects):
    col_total = 0.0
    for i in range(num_students):
        col_total += marks_matrix[i][j]
    subj_avg = col_total / num_students
    print(f"Subject {j + 1}: Average = {subj_avg:.2f}")
    if subj_avg < 50.0:
        weak_subjects.append(j + 1)

if len(weak_subjects) > 0:
    print("Weak Subjects (Avg < 50.0): Subject(s)", weak_subjects)
else:
    print("No weak subjects detected.")
```

## 8. Test Cases
* **Normal Case:** `2` students, `3` subjects; Student A `[80, 75, 90]`, Student B `[60, 65, 70]` $\rightarrow$ Student A top (`245.0`), no weak subjects.
* **Weak Subject Case:** `2` students, `2` subjects; `[40, 85]` and `[30, 90]` $\rightarrow$ Subject 1 average is `35.0` (flagged weak), Subject 2 average is `87.5`.
* **Invalid Mark Case:** Entering `105` or `-2` $\rightarrow$ Rejected until a valid mark in `0–100` is entered.

## 9. Output Screenshots
Run `case_study_42_marks_matrix.py` with a sample student marks matrix and capture the screenshot.

## 10. Conclusion
The program analyzes multi-subject student scores using nested lists and row/column loops to compute averages, highlight top performers, and identify weak subjects.