# Case Study 27: Advanced Numeric Pattern Generator

## 1. Problem Statement
Produce a hollow numeric diamond pattern based on user-specified dimensions, with validation for invalid dimensions and carefully aligned output.

## 2. Objectives
* Validate user input so dimensions are odd integers `>= 3` (forming a symmetric diamond with a clear hollow center).
* Use nested loops and string formatting/alignment to print a symmetric hollow numeric pattern.

## 3. Assumptions
* Dimension `n` represents the total height (number of rows) of the diamond, which must be an odd integer `>= 3` (e.g., `5`, `7`, `9`).
* Row numbers `1` to `mid` expand outward and rows `mid + 1` to `n` contract inward, where `mid = (n + 1) // 2`.
* Outer edge digits use the row index (`1` to `mid` and back down), while inner hollow spaces keep the diamond hollow.

## 4. Algorithm
1. Start.
2. Read `n` from the user; validate that `n >= 3` and `n % 2 == 1`.
3. Set `mid = (n + 1) // 2`.
4. Loop `row` from `1` to `n`:
   * Determine `level`: if `row <= mid`, `level = row`; else `level = n - row + 1`.
   * Calculate leading spaces to center the row.
   * If `level == 1`, print a single digit `1`.
   * Else, print `level`, followed by hollow spaces (`2 * (level - 1) - 1` spaces), followed by `level`.
5. Stop.

## 5. Flowchart
```text
[Start]
   |
   v
[Read n; loop until n >= 3 and n % 2 == 1]
   |
   v
[mid = (n + 1) // 2]
   |
   v
[For row = 1 to n]
   |-- level = row if row <= mid else n - row + 1
   |-- Print leading spaces
   |-- If level == 1: print "1"
   |-- Else: print level + inner spaces + level
   |
   v
[Stop]
```

## 6. Pseudocode
```text
BEGIN
    REPEAT
        READ n
        IF n < 3 OR n MOD 2 == 0 THEN
            PRINT "Enter an odd integer >= 3"
        END IF
    UNTIL n >= 3 AND n MOD 2 == 1

    mid = (n + 1) // 2
    FOR row FROM 1 TO n DO
        IF row <= mid THEN
            level = row
        ELSE
            level = n - row + 1
        END IF

        lead_spaces = (mid - level) * 2
        PRINT " " * lead_spaces WITHOUT NEWLINE

        IF level == 1 THEN
            PRINT "1"
        ELSE
            inner_spaces = (2 * (level - 1) - 1) * 2
            PRINT level, " " * inner_spaces, level
        END IF
    END FOR
END
```

## 7. Python Source Code
```python
n = int(input("Enter diamond height n (odd integer >= 3): "))
while n < 3 or n % 2 == 0:
    print("Invalid dimension! Please enter an odd integer greater than or equal to 3.")
    n = int(input("Enter diamond height n (odd integer >= 3): "))

mid = (n + 1) // 2

print(f"\n--- Hollow Numeric Diamond (Height = {n}) ---\n")
for row in range(1, n + 1):
    if row <= mid:
        level = row
    else:
        level = n - row + 1

    # Print leading spaces using a loop
    leading_spaces = (mid - level) * 2
    for _ in range(leading_spaces):
        print(" ", end="")

    if level == 1:
        print(f"{level}")
    else:
        inner_spaces = (2 * (level - 1) - 1) * 2
        print(f"{level}", end="")
        for _ in range(inner_spaces):
            print(" ", end="")
        print(f"{level}")
```

## 8. Test Cases
* **Normal Case (`n = 5`):** `mid = 3`; prints symmetric hollow diamond with `1` at top/bottom, `2   2` on row 2 & 4, and `3       3` on middle row 3.
* **Boundary Case (`n = 3`):** Smallest valid odd diamond (`1` on row 1, `2   2` on row 2, `1` on row 3).
* **Invalid Input Case (`n = 4` or `n = 1`):** Rejected with clear message until valid input like `5` is entered.

## 9. Output Screenshots
Execute `case_study_27_numeric_pattern.py` with `n = 5` and capture the aligned pattern output in your screenshot.

## 10. Conclusion
The program validates dimensions and generates a symmetric hollow numeric pattern using loops, arithmetic spacing, and conditional logic.