# Case Study 48: Tuple-Based Employee Shift Conflict Detection

## 1. Problem Statement
Represent employee shifts as tuples, compare time intervals, detect overlapping assignments, and identify employees with conflicting schedules.

## 2. Objectives
* Store employee shift records using tuples `(emp_id, start_hour, end_hour)` inside a list.
* Use tuple unpacking to inspect shift start and end times cleanly.
* Detect overlapping shift intervals for the same employee and report conflicting assignments.

## 3. Assumptions
* Shift times use 24-hour integer hours (`0` to `24`), with `0 <= start_hour < end_hour <= 24`.
* Two shifts `(s1, e1)` and `(s2, e2)` for the same employee overlap if `s1 < e2` and `s2 < e1` (back-to-back shifts like `9–13` and `13–17` do not overlap).

## 4. Algorithm
1. Start.
2. Read number of shifts `k` (`k >= 1`).
3. For each shift, validate `0 <= start_h < end_h <= 24` and append `(emp_id, start_h, end_h)` to `shifts`.
4. Compare all distinct pairs of shifts `(i, j)` with `i < j`:
   * Unpack `id1, s1, e1 = shifts[i]` and `id2, s2, e2 = shifts[j]`.
   * If `id1 == id2` and `s1 < e2` and `s2 < e1`, record a conflict.
5. Display all detected conflicts and list employees with conflicts.
6. Stop.

## 5. Flowchart
```text
[Start]
   |
   v
[Read k shifts & validate 0 <= start < end <= 24]
   |
   v
[Store tuples (emp_id, start_h, end_h) in list]
   |
   v
[Nested pair loop i < j: unpack tuples]
   |-- Same emp_id and s1 < e2 and s2 < e1?
        |-- Yes --> Record conflict & flag employee
   |
   v
[Print conflicting pairs & affected employees]
   |
   v
[Stop]
```

## 6. Pseudocode
```text
BEGIN
    READ k (k >= 1)
    CREATE shifts = []
    FOR idx FROM 1 TO k DO
        READ emp_id
        REPEAT
            READ start_h, end_h
        UNTIL start_h >= 0 AND end_h <= 24 AND start_h < end_h
        APPEND (emp_id, start_h, end_h) TO shifts
    END FOR

    CREATE conflicts = [], flagged_emps = []
    FOR i FROM 0 TO LENGTH(shifts) - 2 DO
        id1, s1, e1 = shifts[i]
        FOR j FROM i + 1 TO LENGTH(shifts) - 1 DO
            id2, s2, e2 = shifts[j]
            IF id1 == id2 AND s1 < e2 AND s2 < e1 THEN
                APPEND (id1, s1, e1, s2, e2) TO conflicts
                IF id1 NOT IN flagged_emps THEN
                    APPEND id1 TO flagged_emps
                END IF
            END IF
        END FOR
    END FOR

    PRINT conflicts AND flagged_emps
END
```

## 7. Python Source Code
```python
k = int(input("Enter number of shift records: "))
while k <= 0:
    print("Number of shift records must be at least 1.")
    k = int(input("Enter number of shift records: "))

shifts = []
for idx in range(1, k + 1):
    emp_id = input(f"\nEnter Employee ID for shift {idx}: ").strip().upper()
    start_h = int(input("Enter start hour (0-23): "))
    end_h = int(input("Enter end hour (1-24): "))
    while start_h < 0 or end_h > 24 or start_h >= end_h:
        print("Invalid shift hours! Ensure 0 <= start_hour < end_hour <= 24.")
        start_h = int(input("Enter start hour (0-23): "))
        end_h = int(input("Enter end hour (1-24): "))

    record = (emp_id, start_h, end_h)
    shifts.append(record)

conflicts = []
conflicted_employees = []

for i in range(len(shifts) - 1):
    id1, s1, e1 = shifts[i]
    for j in range(i + 1, len(shifts)):
        id2, s2, e2 = shifts[j]
        if id1 == id2 and s1 < e2 and s2 < e1:
            conflicts.append((id1, s1, e1, s2, e2))
            if id1 not in conflicted_employees:
                conflicted_employees.append(id1)

print("\n--- Shift Conflict Report ---")
if len(conflicts) == 0:
    print("No overlapping shifts detected.")
else:
    for c_id, st1, en1, st2, en2 in conflicts:
        print(f"CONFLICT for {c_id}: Shift [{st1:02d}:00 - {en1:02d}:00] overlaps with [{st2:02d}:00 - {en2:02d}:00]")
    print("\nEmployees with Conflicting Schedules:", conflicted_employees)
```

## 8. Test Cases
* **Overlap Case:** `E101` has `(E101, 9, 14)` and `(E101, 12, 17)` $\rightarrow$ Conflict detected (`9:00-14:00` overlaps `12:00-17:00`).
* **Back-to-Back Non-Overlap Case:** `E102` has `(E102, 8, 12)` and `(E102, 12, 16)` $\rightarrow$ No conflict (`12 < 12` is false).
* **Invalid Time Case:** `start = 15`, `end = 11` $\rightarrow$ Rejected until `start < end`.

## 9. Output Screenshots
Run `case_study_48_shift_conflict.py` with overlapping and non-overlapping shifts and capture the output screenshot.

## 10. Conclusion
The program detects overlapping employee schedules using tuples, tuple unpacking, and interval comparison logic without external libraries or complex structures.